<?php 
    $UangSendiri = 2000;
    $DariTemen = 3000;
    $jumlah = $UangSendiri + $DariTemen;
    echo "Uang Sendiri: " . $UangSendiri . "<br>" . "Dari Temen: " . $DariTemen . "<br>" . "Jumlah: " . $jumlah;
?>