<?php 
    $celcius = 37.5;
    $fahrenheit = ($celcius * 1.8) + 32;
    echo "Celcius = $celcius<br>";
    echo "Fahrenheit = $fahrenheit";
?>