<?php 
    $angka1 = 2;
    $angka2 = 3;
    echo $angka1 * $angka2;
?>