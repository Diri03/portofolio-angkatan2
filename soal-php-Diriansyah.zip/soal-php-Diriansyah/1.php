<?php 
    $namaSaya = "Diriansyah";
    echo $namaSaya;
?>