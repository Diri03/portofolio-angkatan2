<?php 
    $NamaDepan = "Diriansyah";
    $NamaTengah = "Diriansyah";
    $NamaBelakang = "Diriansyah";
    echo "Nama Depan: " . $NamaDepan . "<br>";
    echo "Nama Tengah: " . $NamaTengah . "<br>";
    echo "Nama Belakang: " . $NamaBelakang;
?>